var installationPath = ""; 

function BrowseForFolder() {
    try {
        var objShell = new ActiveXObject("Shell.Application");
        var objFolder = objShell.BrowseForFolder(0, "Select the installation folder:", 1, 0);
        
        if (objFolder != null) {
            installationPath = objFolder.Self.Path;
            if (installationPath.charAt(installationPath.length - 1) !== "\\") {
                installationPath += "\\";
            }
            document.getElementById("pathInput").value = installationPath;
        }
    } catch (e) {
        alert("Folder Selection Error: " + e.message);
    }
}

function downloadUnui() {
    var downloadBar = document.getElementById('downloadBar');
    var downloadInfo = document.getElementById('downloadInfo');
    var fso = new ActiveXObject("Scripting.FileSystemObject");
    
    var loc = decodeURI(window.location.pathname);
    if (loc.charAt(0) === "/" || loc.charAt(0) === "\\") {
        if (loc.charAt(2) === ":") {
            loc = loc.substring(1);
        }
    }
    var currentFolder = fso.GetParentFolderName(loc) + "\\";

    var count = 0;

    if (installationPath === "") {
        installationPath = document.getElementById("pathInput").value;
        if (installationPath !== "" && installationPath.charAt(installationPath.length - 1) !== "\\") {
            installationPath += "\\";
        }
    }

    var interval = setInterval(function() { 
        count++;
        
        if (count == 1) {
            downloadInfo.innerText = "Extracting 'style.css'...";
            if (fso.FileExists(currentFolder + "style.css")) {
                fso.CopyFile(currentFolder + "style.css", installationPath + "style.css", true);
            } else {
                alert("Source file missing: " + currentFolder + "style.css");
                clearInterval(interval);
            }
        } 
        if (count == 2) {
            downloadInfo.innerText = "Extracting 'pathChoose.html'...";
            if (fso.FileExists(currentFolder + "pathChoose.html")) {
                fso.CopyFile(currentFolder + "pathChoose.html", installationPath + "pathChoose.html", true);
            }
        }
        if (count == 3) {
            downloadInfo.innerText = "Installing local VBScript Environment...";
        }
        if (count == 4) {
            downloadInfo.innerText = "Extracting pages/VBSinstaller...";
        }
        
        if (count === 5) {
            clearInterval(interval);
            downloadInfo.innerText = "Installation Complete!";
        }
        
        if (downloadBar) {
            downloadBar.value += 20; 
        }
    }, 1000);
}

function openPage(path) {
    try {
        var fso = new ActiveXObject("Scripting.FileSystemObject");
        var loc = decodeURI(window.location.pathname);
        
        if (loc.charAt(0) === "/" || loc.charAt(0) === "\\") {
            if (loc.charAt(2) === ":") {
                loc = loc.substring(1);
            }
        }
        
        var folder = fso.GetParentFolderName(loc);
        var fullPath = fso.BuildPath(folder, path);

        if (fso.FileExists(fullPath)) {
            var file = fso.OpenTextFile(fullPath, 1);
            var content = file.AtEndOfStream ? "" : file.ReadAll();
            file.Close();
            document.getElementById("main-content").innerHTML = content;
        } else {
            alert("File not found at: " + fullPath);
        }
    } catch (e) {
        alert("Error opening page: " + e.message);
    }

    if (path == '../pages/install.html') { 
        downloadUnui(); 
    }
}
function startDownload() {
    var fso = new ActiveXObject("Scripting.FileSystemObject");
    var shell = new ActiveXObject("WScript.Shell");
    
    // 1. Get the Desktop path automatically (works on any computer)
    var desktopPath = shell.SpecialFolders("Desktop");
    var saveFolder = desktopPath + "\\UIproject (Unui)\\installFolder";
    var savePath = saveFolder + "\\test.html";
    var url = "http://buttonclicker.ca/Unui/test.html"; 

    // 2. Create the folders if they are missing
    try {
        var pathParts = saveFolder.split("\\");
        var currentPath = "";
        for (var i = 0; i < pathParts.length; i++) {
            currentPath += pathParts[i] + "\\";
            if (!fso.FolderExists(currentPath)) {
                fso.CreateFolder(currentPath);
            }
        }
    } catch(e) {
        alert("Folder Creation Error: " + e.message);
        return;
    }

    // 3. Start the Download
    try {
        var xmlHttp = new ActiveXObject("MSXML2.XMLHTTP");
        xmlHttp.open("GET", url, true); // true = Async (No freezing)
        
        xmlHttp.onreadystatechange = function() {
            if (xmlHttp.readyState == 4) {
                if (xmlHttp.status == 200) {
                    var stream = new ActiveXObject("ADODB.Stream");
                    stream.Type = 1; // Binary
                    stream.Open();
                    stream.Write(xmlHttp.responseBody);
                    stream.SaveToFile(savePath, 2); 
                    stream.Close();

                    alert("Saved to: " + savePath);
                    // Use quotes around the path to handle the spaces in "Nathan Henry"
                    shell.Run('"' + savePath + '"'); 
                } else {
                    alert("404 Error: File not found on server at " + url);
                }
            }
        };
        xmlHttp.send();
    } catch (e) {
        alert("Download Error: " + e.message);
    }
}


